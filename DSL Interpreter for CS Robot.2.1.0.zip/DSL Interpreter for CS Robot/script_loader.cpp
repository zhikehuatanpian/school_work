#include "head.h"
unordered_map<string, int> Key_map = unordered_map<string, int>();
bool inited = false;

string script;              //脚本字符串
int script_length;
int pl, pr = -1;            //脚本字符串的左右指针
int line = 1, p_line_start; //行数；指向当前行开头的指针
bool escape = false;        //该标志为true时，前一个字符为转义字符
string str_temp;
stack<int> page_stack;      //页面序号栈
int page_n;                 //页面总数
#define now_char    script[pr]
#define now_page    (pages[page_stack.top()])

Unit next_unit;                 //脚本中识别出的下一个单元

#define OP_N 10                 //符号总数
bool is_operator[256] = {0};    //符号表，用于判断一个字符是否为OP类型
#define next_op     (next_unit.type==OP?next_unit.val[0]:0)         //脚本分析中遇到的下一个符号

//逻辑表达式，分支循环结构相关
stack<Unit> op_stack, str_stack;                        //用于中缀逻辑表达式转后缀逻辑表达式的栈
#define top_op      (op_stack.top().val[0])             //符号分析栈顶的运算符
unordered_map<int, stack<int> > if_stack, while_stack;  //用于每个页面中if/while语句的嵌套识别

void interpreter_init() {
    pages.clear();
    id_map.clear();
    page_n = 1;
    while (!page_stack.empty()) page_stack.pop();
    pl = 0;
    pr = -1;
    line = 1;
    escape = 0;
    //建立0号页面
    pages.__emplace_back(Page());
    page_stack.push(0);
    //空语句初始化
    pages[0].stats.__emplace_back(Statement(NONE, ""));
    //内置变量ret, index初始化
    Statement stat = Statement(VAR, "ret");
    stat.units.__emplace_back(Unit(STR, ""));
    id_map["ret"] = Pair(0, 1);
    pages[0].stats.push_back(stat);
    stat = Statement(VAR, "index");
    stat.units.__emplace_back(Unit(STR, ""));
    id_map["index"] = Pair(0, 2);
    pages[0].stats.push_back(stat);
    //关键字表，符号表初始化
    if (!inited) {
        string key_list[KEY_N] = {"", "text", "link", "page", "show", "var", "get", "func", "code", "if", "else", "elsif", "end", "while", "endloop"};
        for (int i = 0; i < KEY_N; i++) Key_map[key_list[i]] = i;
        char op_list[OP_N] = {'(', ')', '{', '}', '&', '|', '=', '!', ',', '-'};
        for (char i : op_list) is_operator[i] = 1;
        inited = 1;
    }
}

void annotation_process(){  //脚本分析中的注释处理
    pr++;
    if (pr >= script_length) return;
    if (now_char == '#'){   //多行注释
        do{
            if (now_char == '\\') escape = 1;
            else escape = 0;
            pr++;
            if (now_char == '\n'){
                line++; p_line_start = pr;
            }
            if (pr == script_length) return;
        }while (now_char != '#' || escape);
        pr++;
    }else{                  //单行注释
        while (now_char != '\n'){
            pr++;
            if (pr == script_length) return;
        }
    }
}

bool space_process(){ //脚本分析中的分隔符处理
    do{
        pr++;
        if (pr >= script_length) return 0;
        if (now_char == '#') annotation_process();
        if (now_char == '\n'){
            line++; p_line_start = pr;
        }
    }while (now_char == ' ' || now_char == '\t' || now_char == '\n');
    return true;
}

char find_next_char(){ //寻找脚本中除空字符外的下一字符
    if (!space_process()) return 0;
    return now_char;
}

bool get_id(){ //识别出脚本中下一个ID单元
    str_temp = "";
    pl = pr;
    while (isdigit(now_char) || isupper(now_char) || islower(now_char) || now_char == '_'){
        pr++;
    }
    if (now_char != ' ' && now_char != '\n' && now_char != '\t') {
        return false;
    }
    if (now_char == '\n'){
        line++; p_line_start = pr;
    }
    //用str_temp存储识别出的ID字符串
    str_temp = script.substr(pl, pr - pl);
    return true;
}

bool get_str(){ //识别出脚本中下一个STR单元
    str_temp = "";
    while (true){
        pr++;
        if (pr == script_length) return false; //文本右括号缺失错误
        if (now_char == ']' && !escape) break;
        if (!escape){
            if (now_char == '\n') {
                line++; p_line_start = pr;
            }
            if (now_char == '\\') escape = 1;
            else str_temp.append(script, pr, 1);
        }else{ //转义
            if (now_char == 'n'){
                str_temp.append("\n");
            }else if (now_char == 't'){
                str_temp.append("\t");
            }else{
                str_temp.append(script, pr, 1);
                if (now_char == '\n'){
                    line++; p_line_start = pr;
                }
            }
            escape = 0;
        }
    }
    return true;
}

void find_next_unit(){  //获取脚本中下一个语法单元
    char next_char = find_next_char();
    if (!next_char){
        next_unit = Unit(); return;
    }
    if (next_char == '['){              //单元类型为STR
        if (!get_str()) next_unit = Unit(UNKNOWN, "");
        next_unit = Unit(STR, str_temp);
    }else if (is_operator[next_char]){  //单元类型为OP
        next_unit = Unit(OP, &next_char);
    }else{                              //单元类型为ID
        if (!get_id()) next_unit = Unit(UNKNOWN, "");
        else if (Key_map[str_temp] != 0) next_unit = Unit(KEY, str_temp);
        else next_unit = Unit(ID, str_temp);
    }
}

//错误处理函数，输出错误相关信息
//type:错误类型  *unit:传递错误相关信息
void error_process(int type, Unit *unit){
    cerr << "error at line " << line << " char " << pr - p_line_start - 1 << ":\n";
    string error_description;
    switch (type){
        case 1: error_description = "关键字输入错误"; break;
        case 2: error_description = "动态库打开失败"; break;
            break;
        case 3: error_description = "语句格式错误，该处需要";
            if (unit != nullptr){
                if (unit->type == ID) error_description = error_description + "ID";
                else if (unit->type == STR) error_description = error_description + "文本";
                else if (unit->type == OP) error_description = error_description + "符号" + (unit->val)[0];
            }
            break;
        case 4: error_description = "对象id已被占用"; break;
        case 5: error_description = "逻辑表达式格式错误"; break;
        case 6: error_description = "变量未初始化"; break;
        case 7: error_description = "if-else-end语句未匹配"; break;
        case 8: error_description = "while-endloop语句未匹配"; break;
        default: error_description = "未知错误";
    }
    cerr << error_description << endl;
}

int script_process(string filename){
    ifstream input_file;
    input_file.open(filename);
    if (!input_file.is_open()){
        cerr << "打开脚本文件失败" << endl;
        return 0;
    }else{
        //初始化
        interpreter_init();
        //创建脚本输入字符流
        stringstream str_buffer;
        str_buffer << input_file.rdbuf();
        input_file.close();
        script = str_buffer.str();
        str_buffer.clear();
        script_length = script.size();
        //通过有限状态自动机递归预测分析脚本，将脚本内容储存在pages容器中
        int state = 0;
        find_next_unit();
        Statement statement;
        while (true){
            switch (state) {
                case 0:
                    //初始状态
                    if (next_unit.type == KEY) { //识别关键字
                        statement.type = Key_map[next_unit.val];
                        switch (statement.type) {
                            case TEXT: state = 1; break;
                            case LINK: state = 2;break;
                            case PAGE: case CODE: state = 3; break;
                            case SHOW: case GET: state = 4; break;
                            case VAR: state = 5; break;
                            case FUNC: state = 6; break;
                            case IF: case WHILE: case ELSIF: state = 7; break;
                            case ELSE: state = 8; break;
                            case END: state = 13; break;
                            case ENDLOOP: state = 14; break;
                            default:
                                error_process(1, nullptr);
                                return 0;
                        }
                    } else if (next_unit.type == OP) {
                        if (next_op == '-') state = 9; //预处理
                        else if (next_op == '}' && now_page.id != "") { //页面出栈
                            if (!if_stack[page_stack.top()].empty()){
                                error_process(7, nullptr);
                            }
                            page_stack.pop();
                            find_next_unit();
                        } else {
                            error_process(1, nullptr);
                            return 0;
                        }
                    } else if (next_unit.type == NONE) { //识别正常结束
                        if_stack.clear(); while_stack.clear();
                        return 1;
                    } else {
                        error_process(1, nullptr);
                        return 0;
                    }
                    break;
                case 1: //text语句识别
                    find_next_unit();
                    if (next_unit.type == ID) {
                        statement.id = next_unit.val;
                        id_map[statement.id] = Pair(page_stack.top(), now_page.stats.size());
                        find_next_unit();
                        if (next_op != '=') {
                            Unit expected_unit = Unit(OP, "=");
                            error_process(3, &expected_unit);
                            return 0;
                        }
                        find_next_unit();
                    }
                    if (next_unit.type != STR) {
                        Unit expected_sign = Unit(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    while (next_unit.type == STR) {
                        statement.units.push_back(next_unit);
                        find_next_unit();
                    }
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 2: //link语句识别
                    find_next_unit();
                    if (next_unit.type == ID) {
                        statement.id = next_unit.val;
                        id_map[statement.id] = Pair(page_stack.top(), now_page.stats.size());
                        find_next_unit();
                        if (next_op != '=') {
                            Unit expected_sign = Unit(OP, "=");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        find_next_unit();
                    }
                    if (next_op != '{') {
                        Unit expected_sign = Unit(OP, "{");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    //至少读入一个ID/STR
                    find_next_unit();
                    if (next_unit.type != ID && next_unit.type != STR) {
                        Unit expected_sign = Unit(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.units.push_back(next_unit);
                    find_next_unit();
                    while (next_unit.type == ID || next_unit.type == STR) {
                        statement.units.push_back(next_unit);
                        find_next_unit();
                    }
                    if (next_op != '}') {
                        Unit expected_sign = Unit(OP, "}");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    find_next_unit();
                    state = 0;
                    break;
                case 3: //page/code语句识别
                    find_next_unit();
                    if (next_unit.type != ID) {
                        Unit expected_sign = Unit(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    if (id_exists(next_unit.val)) {
                        error_process(4, nullptr);
                        return 0;
                    }
                    statement.units.__emplace_back(Unit(STR, to_string(page_n)));
                    statement.id = next_unit.val;
                    id_map[statement.id] = Pair(0, pages[0].stats.size());
                    pages[0].stats.push_back(statement);
                    page_stack.push(page_n++);
                    pages.push_back(Page(statement.id));
                    statement = Statement();
                    find_next_unit();
                    if (next_op != '=') {
                        Unit expected_sign = Unit(OP, "=");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_unit();
                    if (next_op != '{') {
                        Unit expected_sign = Unit(OP, "{");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_unit();
                    state = 0;
                    break;
                case 4: //show/get语句识别
                    find_next_unit();
                    if (next_unit.type != ID) {
                        Unit expected_sign = Unit(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.id = next_unit.val;
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    find_next_unit();
                    state = 0;
                    break;
                case 5: //var语句识别
                    find_next_unit();
                    if (next_unit.type != ID) {
                        Unit expected_sign = Unit(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    if (!id_exists(next_unit.val)) { //变量初始声明
                        string var_id = next_unit.val;
                        find_next_unit();
                        if (next_unit.type != STR) {
                            error_process(6, nullptr);
                            return 0;
                        }
                        id_map[var_id] = Pair(0, pages[0].stats.size());
                        statement.id = var_id;
                        statement.units.__emplace_back(Unit(STR, next_unit.val));
                        pages[0].stats.push_back(statement);
                        find_next_unit();
                    } else {
                        if (id_to_stat(next_unit.val).type != VAR) {
                            error_process(4, nullptr);
                            return 0;
                        }
                        statement.id = next_unit.val;
                        find_next_unit();
                        if (next_op != '=') {
                            Unit expected_sign = Unit(OP, "=");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        find_next_unit();
                        if (next_unit.type != ID && next_unit.type != STR) {
                            Unit expected_sign = Unit(STR, "");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        while (next_unit.type == ID || next_unit.type == STR) {
                            statement.units.push_back(next_unit);
                            find_next_unit();
                        }
                        now_page.stats.push_back(statement);
                    }
                    statement = Statement();
                    state = 0;
                    break;
                case 6: //func语句识别
                    find_next_unit();
                    if (next_unit.type != ID) {
                        Unit expected_sign = Unit(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.id = next_unit.val;
                    find_next_unit();
                    if (next_op != '{') {
                        Unit expected_sign = Unit(OP, "{");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_unit();
                    if (next_unit.type != STR && next_unit.type != ID) {
                        Unit expected_sign = Unit(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    while (next_unit.type == STR || next_unit.type == ID) {
                        statement.units.push_back(next_unit);
                        find_next_unit();
                    }
                    if (next_op != '}') {
                        Unit expected_sign = Unit(OP, "}");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_unit();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 7: { //if/while/elsif识别
                    while (!op_stack.empty()) op_stack.pop();
                    while (!str_stack.empty()) str_stack.pop();
                    find_next_unit();
                    if (next_op != '(') {
                        Unit expected_sign = Unit(OP, "(");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    if (statement.type == IF) if_stack[page_stack.top()].push(now_page.stats.size());
                    else if (statement.type == WHILE) while_stack[page_stack.top()].push(now_page.stats.size());
                    else {
                        if (!if_stack[page_stack.top()].empty()){
                            //elsif取代最近的一个if入栈
                            now_page.stats[if_stack[page_stack.top()].top()].id = to_string(now_page.stats.size());
                            if_stack[page_stack.top()].pop();
                            if_stack[page_stack.top()].push(now_page.stats.size());
                        }else {
                            error_process(7, nullptr);
                            return 0;
                        }
                    }
                    op_stack.push(next_unit);
                case 10: //逻辑表达式 上一个符号为'('的状态
                    find_next_unit();
                    if (next_op == '(') {
                        op_stack.push(next_unit);
                        state = 10;
                    } else if (next_unit.type == STR || next_unit.type == ID) {
                        str_stack.push(next_unit);
                        find_next_unit();
                        if (next_op == '=' || next_op == '!') {
                            op_stack.push(next_unit);
                        } else {
                            error_process(5, nullptr);
                            return 0;
                        }
                        find_next_unit();
                        if (next_unit.type == STR || next_unit.type == ID) {
                            str_stack.push(next_unit);
                        } else {
                            error_process(5, nullptr);
                            return 0;
                        }
                        state = 11;
                    } else {
                        error_process(5, nullptr);
                        return 0;
                    }
                    break;
                }
                case 8:
                    if (if_stack[page_stack.top()].empty()) {
                        error_process(7, nullptr);
                        return 0;
                    }
                    //else匹配最近的一个if，并将if出栈
                    now_page.stats[if_stack[page_stack.top()].top()].id = to_string(now_page.stats.size());
                    if_stack[page_stack.top()].pop();
                    if_stack[page_stack.top()].push(now_page.stats.size());
                    find_next_unit();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 9: //设置动态库目录的语句
                    find_next_unit();
                    if (next_unit.val == "SET_DLL_DIRECTORY"){
                        find_next_char();
                        pl = pr;
                        while (now_char != ' ' && now_char != '\n' && now_char != '\t') pr++;
                        if (now_char == '\n'){
                            line++; p_line_start = pr;
                        }
                        string dll_directory = script.substr(pl, pr - pl);
                        lib_handle = dlopen(dll_directory.c_str(), RTLD_LAZY);
                        if (lib_handle == NULL){
                            error_process(2, nullptr); return 0;
                        }
                    }
                    find_next_unit();
                    state = 0;
                    break;
                case 11: //逻辑表达式 上一个符号为')'的状态
                    find_next_unit();
                    if (next_op == '&' || next_op == '|'){
                        statement.units.push_back(str_stack.top());
                        str_stack.pop();
                        statement.units.push_back(str_stack.top());
                        str_stack.pop();
                        while (top_op != '(') {
                            statement.units.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.push(next_unit);
                        state = 10;
                    }else if (next_op == ')'){
                        statement.units.push_back(str_stack.top());
                        str_stack.pop();
                        statement.units.push_back(str_stack.top());
                        str_stack.pop();
                        while (top_op != '(') {
                            statement.units.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.pop();
                        if (op_stack.empty()){
                            find_next_unit();
                            now_page.stats.push_back(statement);
                            statement = Statement();
                            state = 0;
                        }else{
                            state = 12;
                        }
                    }else{
                        error_process(5, nullptr);
                        return 0;
                    }
                    break;
                case 12: //逻辑表达式 上一个符号为STR/ID的状态
                    find_next_unit();
                    if (next_op == '&' || next_op == '|'){
                        while (top_op != '(') {
                            statement.units.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.push(next_unit);
                        state = 10;
                    }else if (next_op == ')'){
                        while (top_op != '(') {
                            statement.units.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.pop();
                        if (op_stack.empty()){
                            find_next_unit();
                            now_page.stats.push_back(statement);
                            statement = Statement();
                            state = 0;
                        }
                    }else{
                        error_process(5, nullptr);
                        return 0;
                    }
                    break;
                case 13: //end
                    if (!if_stack[page_stack.top()].empty()){ //让最近的if指向这个end
                        now_page.stats[if_stack[page_stack.top()].top()].id = to_string(now_page.stats.size());
                        if_stack[page_stack.top()].pop();
                    }else{
                        error_process(7, nullptr);
                        return 0;
                    }
                    find_next_unit();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 14: //endloop
                    if (!while_stack[page_stack.top()].empty()){
                        now_page.stats[while_stack[page_stack.top()].top()].id = to_string(now_page.stats.size());
                        statement.id = to_string(while_stack[page_stack.top()].top());
                        while_stack[page_stack.top()].pop();
                    }else{
                        error_process(8, nullptr);
                        return 0;
                    }
                    find_next_unit();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                default: return 0;
            }
        }
    }
}

