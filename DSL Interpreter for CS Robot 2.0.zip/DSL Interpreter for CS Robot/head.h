#ifndef HEAD_H
#define HEAD_H
#endif

#include <iostream>
#include <fstream>
#include <sstream>

#include <vector>
#include <map>
#include <unordered_map>
#include <set>

#include <sys/event.h>
#include <sys/time.h>
#include <dlfcn.h>

using namespace std;

extern string now_script;
extern int administer_mode;

enum KEY_TYPE {
    NONE, TEXT, LINK, PAGE, SHOW, VAR, GET, FUNC, CODE, IF, ELSE, ELSIF, END, WHILE, ENDLOOP, KEY_N
};
enum COMMAND_TYPE {
    QUIT = 1, GO, LOAD, REFRESH, RETURN, SHOW_STATE, COMMAND_N
};
enum UNIT_TYPE {
    STR = 1, ID, OP, KEY, UNKNOWN
};

extern unordered_map<string, int> Key_map;     //关键字表
extern unordered_map<string, int> Command_map; //
extern unordered_map<string, string> var_map;  //存放用户变量，每个用户单独拥有

struct Unit{                //语法单元，存储特定类型的字符常量
    int type = NONE;
    string val;
    Unit() = default;
    Unit(int _type, string _val){
        type = _type, val = _val;
    }
};

typedef struct Statement{   //语句，存储语法单元序列
    int type = NONE;
    string id = "";
    vector<Unit> units;
    Statement() = default;
    Statement(int _type, string _id){
        type = _type;
        id = _id;
    }
}*pStatement;

struct Page{                //页面，存储语句序列
    string id;
    vector<Statement> stats;
    Page() = default;
    Page(string &_id){
        id = _id;
    }
};
extern vector<Page> pages;  //存储脚本所有页面信息
typedef pair<int,int> Pair;
extern unordered_map<string, Pair> id_map;          //从语句ID获取pages中存放对应语句的下标(i, j)
#define ID_to_stat(x)   (pages[id_map[x].first].stats[id_map[x].second])    //由ID获取对应语句
#define ID_exists(x)    (id_map[x].first || id_map[x].second)               //检查ID是否存在
#define ID_type(x)      (ID_exists(x)?ID_to_stat(x).type:0)                 //由ID获取对应类型

extern void* lib_handle;    //动态库指针

int script_process(string filename);

bool interpret(string command);
void init_command_map();
void read_config();
void print_page(int idx);

void print_syntax_tree();
void print_user_state(int now_page_idx);

