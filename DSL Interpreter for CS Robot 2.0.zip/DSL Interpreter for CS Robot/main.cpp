#include "head.h"
unordered_map<string, Pair> id_map = unordered_map<string, Pair>();      //存储id所指对象的位置
unordered_map<string, string> var_map = unordered_map<string, string>(); //存储变量的值
vector<Page> pages = vector<Page>();
void* lib_handle = NULL;

int administer_mode = 0;
string now_script = "start.txt";

int main() {
    read_config();
    init_command_map();
    interpret("load " + now_script);
    while(true){
        string command;
        getline(cin, command);
        if (!interpret(command)) break;
    }
    return 0;
}
