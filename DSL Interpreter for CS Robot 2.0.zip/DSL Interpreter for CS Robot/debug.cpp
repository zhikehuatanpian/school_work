#include "head.h"

string key_list[KEY_N] = {"NONE", "TEXT", "LINK", "PAGE", "SHOW", "VAR", "GET", "FUNC", "CODE", "IF", "ELSE", "ELSIF", "END", "WHILE", "ENDLOOP"};
string type_list[UNKNOWN] = {"", "STR", "ID", "OP", "KEY"};

void print_syntax_tree(){
    for (int i = 0; i < pages.size(); i++){
        cout << "Page " << pages[i].id << ":\n" ;
        for (int j = 0; j < pages[i].stats.size(); j++) {
            cout << "\tstat type: " << key_list[pages[i].stats[j].type];
            if (pages[i].stats[j].id != "") cout << "  id: " << pages[i].stats[j].id;
            cout << endl;
            for (int k = 0; k < pages[i].stats[j].units.size(); k++) {
                if (pages[i].stats[j].units[k].type == OP) cout << "\t\tunit" << k << ": " << type_list[pages[i].stats[j].units[k].type] << "  " << pages[i].stats[j].units[k].val[0] << endl;
                else cout << "\t\tunit" << k << ": " << type_list[pages[i].stats[j].units[k].type] << " " << pages[i].stats[j].units[k].val << endl;
            }
        }
    }
}

void print_user_state(int now_page_idx){
    cout << "当前页面信息：\n";
    cout << "Page " << pages[now_page_idx].id << ":\n" ;
    for (int j = 0; j < pages[now_page_idx].stats.size(); j++) {
        cout << "\tstat type: " << key_list[pages[now_page_idx].stats[j].type];
        if (pages[now_page_idx].stats[j].id != "") cout << "  id: " << pages[now_page_idx].stats[j].id;
        cout << endl;
        for (int k = 0; k < pages[now_page_idx].stats[j].units.size(); k++) {
            if (pages[now_page_idx].stats[j].units[k].type == OP) cout << "\t\tunit" << k << ": " << type_list[pages[now_page_idx].stats[j].units[k].type] << "  " << pages[now_page_idx].stats[j].units[k].val[0] << endl;
            else cout << "\t\tunit" << k << ": " << type_list[pages[now_page_idx].stats[j].units[k].type] << " " << pages[now_page_idx].stats[j].units[k].val << endl;
        }
    }
    cout << "当前用户变量：\n";
    for (auto t = var_map.begin(); t != var_map.end(); t++){
        cout << "\t" << (*t).first << ": " << (*t).second << endl;
    }
}
