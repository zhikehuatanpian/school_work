#include "head.h"

#define now_stat (pages[idx].stats[i])
#define now_page_idx  (page_num_stack.top())

unordered_map<string, int> Command_map = unordered_map<string, int>();
stack<int> page_num_stack;      //页面栈，存放从加载开始所经过的页码
unordered_map<int, bool> page_printed;  //标记已经输出过的页面，防止页面无限嵌套输出

vector<Pair> links;             //当前页面中的链接列表

Pair go_stat_idx;

int str_to_int(string s){
    int l = s.size(), an = 0;
    for (int i = 0; i < l; i++){
        if (s[i]<'0' || s[i]>'9') return -1;
        an = an * 10 + s[i] - '0';
    }
    return an;
}

void init_command_map(){
    string command_list[COMMAND_N] = {"", "quit", "go", "load", "refresh", "return", "show_state"};
    for (int i = 0; i < COMMAND_N; i++) Command_map[command_list[i]] = i;
}

void print_init(){ //输出页面前，清空链接和页面已输出标记
    links.clear();
    page_printed.clear();
    cout <<"-------------------------------------------------------------" << endl;
    page_printed[0] = 1;
}

void refresh(int page_id){
    print_init();
    go_stat_idx = Pair();
    print_page(page_id);
}

string get_unit_val(Unit *unit){
    if (unit->type == ID){
        if (ID_exists(unit->val)){
            pStatement p = &ID_to_stat(unit->val);
            if (p->type == VAR) {
                return var_map[unit->val];
            }else if (p->type == TEXT || p->type == LINK) {
                return p->units[0].val;
            }else return "";
        }else return "";
    }
    return unit->val;
}

void print_link(int idx, int i){ //输出链接
    cout << "\t\t[" << get_unit_val(&now_stat.units[0]) << "]";
    //放入链接列表
    links.push_back(Pair(idx, i));
    cout << "(" << links.size() << ")" << endl;
    int l = now_stat.units.size();
    if (Pair(idx, i) == go_stat_idx) //展开文本
        for (int k = 1; k < l; k++) {
            if (now_stat.units[k].type == STR) {
                cout << "\t\t\t---" << get_unit_val(&now_stat.units[k]) << endl;
            } else { //展开引用文本
                pStatement referred_stat = &ID_to_stat(now_stat.units[k].val);
                if (referred_stat->type == LINK) {
                    cout << "\t\t\t---" << get_unit_val(&referred_stat->units[0]) << endl;
                } else if (referred_stat->type == TEXT) {
                    for (int j = 0; j < referred_stat->units.size(); j++)
                        cout << "\t\t\t---" << get_unit_val(&referred_stat->units[j]) << endl;
                } else if (referred_stat->type == VAR) {
                    if (var_map[referred_stat->id] != "")
                        cout << "\t\t\t---" << var_map[referred_stat->id] << endl;
                }
            }
        }
}

bool judge(int idx, int i){
    stack<string> stk;
    for (int j = 0; j < now_stat.units.size(); j++){
        if (now_stat.units[j].type == OP){
            if (now_stat.units[j].val[0] == '='){
                string t = stk.top(); stk.pop();
                if (t == stk.top()){
                    stk.pop();
                    stk.push("1");
                }else{
                    stk.pop();
                    stk.push("0");
                }
            }else if (now_stat.units[j].val[0] == '!'){
                string t = stk.top(); stk.pop();
                if (t == stk.top()){
                    stk.pop();
                    stk.push("0");
                }else{
                    stk.pop();
                    stk.push("1");
                }
            }else if (now_stat.units[j].val[0] == '&'){
                string t = stk.top(); stk.pop();
                string s = stk.top(); stk.pop();
                stk.push(to_string(s=="1" && t=="1"));
            }else if (now_stat.units[j].val[0] == '|'){
                string t = stk.top(); stk.pop();
                string s = stk.top(); stk.pop();
                stk.push(to_string(s=="1" || t=="1"));
            }
        }else{
            stk.push(get_unit_val(&now_stat.units[j]));
        }
    }
    return (stk.top() == "1");
}

void exec_code(int code_id){ //执行代码段
    page_num_stack.push(code_id);
    print_page(code_id);
    page_num_stack.pop();
}

void print_page(int idx){
    bool jump_elsif = 0;
    if (!(ID_to_stat(pages[idx].id).type == CODE)) {
        if (page_printed[idx]) return;
        page_printed[idx] = true;
    }
    int l = pages[idx].stats.size();
    for (int i = 0; i < l; i++){
        switch (now_stat.type) {
            case TEXT:
                for (int j = 0; j < now_stat.units.size(); j++) {
                    cout << "\t" << now_stat.units[j].val << endl;
                }
                break;
            case LINK:
                print_link(idx, i);
                break;
            case VAR: {
                //赋值
                string t;
                for (int j = 0; j < now_stat.units.size(); j++) {
                    t += get_unit_val(&now_stat.units[j]);
                }
                var_map[now_stat.id] = t;
            }break;
            case FUNC: {
                // 直接从库中调用函数名
                typedef string (*Func)(const string &);
                Func func = (Func) dlsym(lib_handle, now_stat.id.c_str());
                if (func != nullptr) {
                    string argument;
                    for (int j = 0; j < now_stat.units.size(); j++) {
                        if (j != 0) argument += " ";
                        if (now_stat.units[j].type == STR) {
                            argument += now_stat.units[j].val;
                        } else if (now_stat.units[j].type == ID && ID_type(now_stat.units[j].val) == VAR){
                            argument += var_map[now_stat.units[j].val];
                        }
                    }
                    var_map["ret"] = func(argument);
                }else{
                    cout << "error：function " << now_stat.id.c_str() << "not_found" << endl;
                }
                break;
            }
            case SHOW: {
                pStatement p_stat_to_go = &ID_to_stat(now_stat.id);
                if (p_stat_to_go == nullptr) {
                    continue;
                }
                if (p_stat_to_go->type == CODE) {
                    exec_code(str_to_int((p_stat_to_go->units)[0].val));
                } else if (p_stat_to_go->type == PAGE) {
                    print_page(str_to_int((p_stat_to_go->units)[0].val));
                } else if (p_stat_to_go->type == VAR) {
                    cout << "\t";
                    if (ID_to_stat(now_stat.id).units[0].val != "") cout << "\t" << ID_to_stat(now_stat.id).units[0].val << ": ";
                    cout << var_map[p_stat_to_go->id] << endl;
                } else if (p_stat_to_go->type == TEXT || p_stat_to_go->type == LINK){
                    now_stat = (*p_stat_to_go);
                    i--;
                }
            }break;
            case GET: {
                //获取变量
                cout << "\t请输入" << ID_to_stat(now_stat.id).units[0].val << ": ";
                getline(cin, var_map[now_stat.id]);
            }break;
            case ENDLOOP:
                i = str_to_int(now_stat.id) - 1;
                break;
            case ELSE:
                i = str_to_int(now_stat.id);
                break;
            case WHILE:
                if (!judge(idx, i)) i = str_to_int(now_stat.id);
                break;
            case IF: case ELSIF:
                //判断表达式是否符合条件，不符合则找到下一个end或elsif或else
                if ((now_stat.type == ELSIF && jump_elsif) || !judge(idx, i)){
                    i = str_to_int(now_stat.id);
                    if (now_stat.type == ELSIF) i--;
                }else{
                    jump_elsif = 1;
                }
                break;
            case END:  jump_elsif = 0;
        }
    }
}

void command_go(int go_idx){
    if (go_idx<0 || go_idx>=links.size()){
        printf("该命令无效，请重新输入\n"); return;
    }
    //设置变量index
    var_map["index"] = to_string(go_idx + 1);
    //获取所要跳转对象的对应语句
    go_stat_idx = links[go_idx];
    Statement go_stat = pages[go_stat_idx.first].stats[go_stat_idx.second];
    for (int j = 1; j < go_stat.units.size(); j++) {
        if (go_stat.units[j].type == ID) {
            Statement next_stat = ID_to_stat(go_stat.units[j].val);
            if (next_stat.type == PAGE && str_to_int(next_stat.units[0].val) != page_num_stack.top()) {
                //页面跳转
                int next_page_id = str_to_int(next_stat.units[0].val);
                page_num_stack.push(next_page_id);
                print_init();
                print_page(next_page_id);
                return;
            } else if (next_stat.type == CODE) { //代码段执行
                exec_code(str_to_int(next_stat.units[0].val));
            }
        }
    }
    print_init();
    print_page(page_num_stack.top());
}

bool command_load(string &filename){ //执行load命令
    if (!script_process("./script/" + filename)){
        cerr << "加载脚本文件失败" << endl;
        return false;
    }else{
        if (ID_to_stat("home").type != PAGE){
            cerr << "未找到主页面" << endl;  return false;
        }
        if (administer_mode) {
            print_syntax_tree();
            cout << "加载脚本文件" << filename << "成功" << endl;
        }
        var_map.clear(); //清空用户变量
        int start_page = str_to_int(ID_to_stat("home").units[0].val);
        while (!page_num_stack.empty()) page_num_stack.pop(); //清空页面栈
        page_num_stack.push(start_page);
        refresh(start_page);
    }
    return true;
}

bool interpret(string command){
    stringstream command_ss(command);
    command_ss >> command;
    int command_type = Command_map[command];
    switch (command_type){
        case NONE: cout << "该命令无效，请重新输入" << endl; break;
        case QUIT: exit(0); break;
        case GO: {
            int go_idx = 0;
            command_ss >> go_idx;
            command_go(go_idx - 1);
        }break;
        case REFRESH:
            refresh(page_num_stack.top());
            break;
        case RETURN:
            if (page_num_stack.size() > 1) {
                page_num_stack.pop();
                refresh(page_num_stack.top());
            }
            break;
        case LOAD:
            if (pages.empty() || administer_mode) {
                string filename;
                command_ss >> filename;
                return command_load(filename);
            }else{
                cout << "该命令无效，请重新输入" << endl;
            }
            break;
        case SHOW_STATE:
            if (administer_mode) print_user_state(now_page_idx);
            else cout << "该命令无效，请重新输入" << endl;
            break;
    }
    return true;
}

void read_config(){
    ifstream config_file("./config.ini");
    if (!config_file) {
        cout << "未找到配置文件，使用默认配置" << endl;
        return;
    }
    string str;
    while (getline(config_file, str)){
        if (str == "[START_SCRIPT]"){
            getline(config_file, str);
            now_script = str;
        }else if (str == "[MODE]"){
            getline(config_file, str);
            administer_mode = (str == "administer");
        }
    }
}
