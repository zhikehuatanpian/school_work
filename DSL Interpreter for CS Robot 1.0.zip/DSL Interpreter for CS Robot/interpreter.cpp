#include "head.h"

#define now_stat (pages[idx].stats[i])

unordered_map<string, int> Command_map = unordered_map<string, int>();
stack<int> page_num_stack; //存放从加载开始所经过的页码

vector<Pair> links;
bool page_printed[MAX_PAGE_N];

Pair ID_of_stat_to_show;

int str_to_int(string s){
    int l = s.size(), an = 0;
    for (int i=0;i<l; i++){
        if (s[i]<'0' || s[i]>'9') return -1;
        an = an*10 + s[i] - '0';
    }
    return an;
}

void init_command_map(){
    // Q, QUIT, GO, LOAD, REFRESH, RETURN, GET
    //Command_map["q"] = Q;
    string command_list[COMMAND_N] = {"", "quit", "go", "load", "refresh", "return"};
    for (int i = 0; i<COMMAND_N; i++) Command_map[command_list[i]] = i;
}

void print_init(){
    links.clear();
    memset(page_printed, 0, sizeof(page_printed));
    cout << "#######################################################" << endl;
    page_printed[0] = 1;
}

void refresh(int page_id){
    print_init();
    ID_of_stat_to_show = Pair();
    print_page(page_id);
}

string get_sign_val(Sign *sign){
    if (sign->type == ID){
        if (ID_exists(sign->val)){
            pStatement p = &ID_to_stat(sign->val);
            if (p->type == VAR) {
                return Val_map[sign->val];
            }else if (p->type == TEXT || p->type == ITEM) {
                return p->signs[0].val;
            }else return "";
        }else return "";
    }
    return sign->val;
}

void print_item(int idx, int i){
    cout << "\t\t[" << get_sign_val(&now_stat.signs[0]) << "]";
    //生成链接
    links.push_back(Pair(idx, i));
    cout << "(" << links.size() << ")" << endl;
    int l = now_stat.signs.size();
    if (Pair(idx, i) == ID_of_stat_to_show)
        for (int k = 1; k < l; k++) {
            if (now_stat.signs[k].type == STR) { //展开文本
                cout << "\t\t\t--" << get_sign_val(&now_stat.signs[k]) << endl;
            } else { //展开引用文本
                pStatement referred_stat = &ID_to_stat(now_stat.signs[k].val);
                if (referred_stat->type == PAGE) {
                    print_page(str_to_int(referred_stat->signs[0].val));
                    return;
                } else if (referred_stat->type == ITEM) {
                    cout << "\t\t\t--" << get_sign_val(&referred_stat->signs[0]) << endl;
                } else if (referred_stat->type == TEXT) {
                    for (int j = 0; j < referred_stat->signs.size(); j++)
                        cout << "\t\t\t--" << get_sign_val(&referred_stat->signs[j]) << endl;
                } else if (referred_stat->type == VAR) {
                    if (Val_map[referred_stat->id] != "")
                        cout << "\t\t\t--" << Val_map[referred_stat->id] << endl;
                }
            }
        }
}

void print_page(int idx){
    bool is_code = (ID_to_stat(pages[idx].id).type == CODE);
    if (!is_code) {
        if (page_printed[idx]) return;
        page_printed[idx] = true;
    }
    int l = pages[idx].stats.size();

    for (int i = 0; i < l; i++){
        switch (now_stat.type) {
            case TEXT:
                if (!is_code) {
                    for (int j = 0; j < now_stat.signs.size(); j++) {
                        cout << "\t" << now_stat.signs[j].val << endl;
                    }
                }
                break;
            case ITEM:
                if (!is_code) print_item(idx, i);
                break;
            case VAR: {
                //赋值
                string t = "";
                for (int j = 0; j < now_stat.signs.size(); j++) {
                    t = t + get_sign_val(&now_stat.signs[j]);
                }
                Val_map[now_stat.id] = t;
            }break;
            case FUNC: {
#ifdef _WIN32
                // 获取函数地址并进行调用
                typedef std::string (*MY_FUNCTION)(const std::string&);
                MY_FUNCTION myFunction = (MY_FUNCTION)GetProcAddress(hLibrary, "myFunction");
                if (myFunction != NULL) {
                    std::string inputString = "World";
                    std::string result = myFunction(inputString);
                    std::cout << "Result: " << result << std::endl;
                }
#else
                // 直接调用函数名
                typedef string (*Func)(const string &);
                Func func = (Func) dlsym(handle, now_stat.id.c_str());
                //cout << now_stat.id;
                if (func != NULL) {
                    string argument = "";
                    for (int j = 0; j < now_stat.signs.size(); j++) {
                        if (j != 0) argument = argument + " ";
                        if (now_stat.signs[j].type == STR) {
                            argument = argument + now_stat.signs[j].val;
                        } else if (now_stat.signs[j].type == ID && ID_type(now_stat.signs[j].val)==VAR){
                            argument = argument + Val_map[now_stat.signs[j].val];
                        }
                    }
                    Val_map["ret"] = func(argument);
                }else{
                    cout << "error：function " << now_stat.id.c_str() << "not_found" << endl;
                }
#endif
                break;
            }
            case SHOW: {
                pStatement p_stat_to_show = &ID_to_stat(now_stat.id);
                if (p_stat_to_show == NULL) {
                    continue;
                }
                if (is_code){
                    if (p_stat_to_show->type == CODE) {
                        int next_page = str_to_int((p_stat_to_show->signs)[0].val);
                        page_num_stack.push(next_page);
                        print_page(next_page);
                        page_num_stack.pop();
                    }
                } else if (p_stat_to_show->type == PAGE) {
                    print_page(str_to_int((p_stat_to_show->signs)[0].val));
                } else if (p_stat_to_show->type == VAR) {
                    cout << "\t";
                    if (ID_to_stat(now_stat.id).signs[0].val != "") cout << "\t" << ID_to_stat(now_stat.id).signs[0].val << ": ";
                    cout << Val_map[p_stat_to_show->id] << endl;
                } else {
                    now_stat = (*p_stat_to_show);
                    i--;
                }
            }break;
            case GET: {
                //获取变量
                cout << "\t请输入" << ID_to_stat(now_stat.id).signs[0].val << ": ";
                getline(cin, Val_map[now_stat.id]);
            }break;
            case ENDLOOP:
                i = str_to_int(now_stat.id) - 1;
                break;
            case ELSE:
                i = str_to_int(now_stat.id);
                break;
            case IF: case WHILE:
                //判断表达式是否符合条件
                stack<string> stk;
                for (int j = 0; j < now_stat.signs.size(); j++){
                    if (now_stat.signs[j].type == OP){
                        if (now_stat.signs[j].val[0] == '='){
                            string t = stk.top(); stk.pop();
                            if (t == stk.top()){
                                stk.pop();
                                stk.push("1");
                            }else{
                                stk.pop();
                                stk.push("0");
                            }
                        }else if (now_stat.signs[j].val[0] == '!'){
                            string t = stk.top(); stk.pop();
                            if (t == stk.top()){
                                stk.pop();
                                stk.push("0");
                            }else{
                                stk.pop();
                                stk.push("1");
                            }
                        }else if (now_stat.signs[j].val[0] == '&'){
                            string t = stk.top(); stk.pop();
                            string s = stk.top(); stk.pop();
                            stk.push(to_string(s=="1" && t=="1"));
                        }else if (now_stat.signs[j].val[0] == '|'){
                            string t = stk.top(); stk.pop();
                            string s = stk.top(); stk.pop();
                            stk.push(to_string(s=="1" || t=="1"));
                        }
                    }else{
                        stk.push(get_sign_val(&now_stat.signs[j]));
                    }
                }
                if (stk.top() != "1"){
                    i = str_to_int(now_stat.id);
                }
                //不符合，找到下一个end或elsif或else
                break;
        }
    }
}

void command_go(int go_idx){
    if (go_idx<0 || go_idx>=links.size()){
        printf("该命令无效，请重新输入\n"); return;
    }
    //cout << label << endl;
    //获取所要跳转对象的id
    ID_of_stat_to_show = links[go_idx];
    //cout << label << endl;
    //获取所要跳转对象的id
    Statement item_to_show = pages[ID_of_stat_to_show.first].stats[ID_of_stat_to_show.second];
    for (int j = 1; j < item_to_show.signs.size(); j++) {
        if (item_to_show.signs[j].type == ID) {
            //引用
            Statement next_stat = ID_to_stat(item_to_show.signs[j].val);
            if (next_stat.type == PAGE && str_to_int(next_stat.signs[0].val) != page_num_stack.top()) {
                //页面跳转
                int next_page_id = str_to_int(next_stat.signs[0].val);
                page_num_stack.push(next_page_id);
                print_init();
                print_page(next_page_id);
                return;
            } else if (next_stat.type == CODE) {
                int next_page_id = str_to_int(next_stat.signs[0].val);
                page_num_stack.push(next_page_id);
                print_page(next_page_id);
                page_num_stack.pop();
            }
        }
    }
    print_init();
    print_page(page_num_stack.top());
}

bool command_load(string &filename){
    if (!script_process("../script/" + filename)){
        cerr << "加载脚本文件失败" << endl;
        return false;
    }else{
        if (ID_to_stat("home").type != PAGE){
            cerr << "未找到主页面" << endl;  return false;
        }
        cout << "加载脚本文件成功" << endl;
        if (debug_mode == 1) print_syntax_tree();
        int start_page = str_to_int(ID_to_stat("home").signs[0].val);
        page_num_stack.push(start_page);
        refresh(start_page);
    }
    return true;
}

bool get_output(string command){
    stringstream command_ss(command);
    command_ss >> command;
    int command_type = Command_map[command];
    switch (command_type){
        case NONE: cout << "该命令无效，请重新输入" << endl; break;
        case QUIT: exit(0); break;
        case GO: {
            int go_idx = 0;
            command_ss >> go_idx;
            command_go(go_idx - 1);
        }break;
        case REFRESH:
            refresh(page_num_stack.top());
            break;
        case RETURN:
            if (page_num_stack.size() > 1) {
                page_num_stack.pop();
                refresh(page_num_stack.top());
            }
            break;
        case LOAD:
            string filename;
            command_ss >> filename;
            return command_load(filename);
            break;
    }
    return true;
}
