#include "head.h"
unordered_map<string, Pair> id_map = unordered_map<string, Pair>();
unordered_map<string, string> Val_map = unordered_map<string, string>();
vector<Page> pages = vector<Page>();
#ifdef _WIN32
    HMODULE hLibrary = NULL;
#else
    void* handle = NULL;
#endif
int debug_mode = 1;
int main() {

    //cout << "val:" << pages[id_map["home"].i].stats[id_map["home"].j].val << endl;
    init_command_map();
    get_output("load start.txt");
    while(true){
        string command;
        getline(cin, command);
        if (!get_output(command)) break;
    }

    return 0;
}
