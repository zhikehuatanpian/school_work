#include "head.h"
unordered_map<string, int> Key_map = unordered_map<string, int>();

string str;
int pl, pr = -1, str_length, line = 1, p_line;

string str_temp; //存放语句中的各个参数
stack<int> page_stack;
int page_n;

#define now_page (pages[page_stack.top()])
#define now_page_n page_stack.top()

bool escape = 0; //该标志为1时，前一个字符为转义字符

#define OP_N 10
bool is_operator[256] = {0};

#define next_op (next_sign.type==OP?next_sign.val[0]:0)

//逻辑表达式相关
stack<Sign> op_stack, str_stack;
stack<int> if_stack[MAX_PAGE_N], else_stack[MAX_PAGE_N], while_stack[MAX_PAGE_N];
#define top_op (op_stack.top().val[0])

void interpreter_init(){
    pages.clear();
    id_map.clear();
    page_n = 1;
    while (!page_stack.empty()) page_stack.pop();
    pl = 0; pr = -1; line = 1;
    escape = 0;
    //建立0号页面
    pages.push_back( Page() );
    page_stack.push(0);
    //空语句初始化
    pages[0].stats.push_back(Statement(NONE, ""));
    //变量ret初始化
    Statement stat = Statement(VAR, "ret");
    stat.signs.push_back(Sign(STR, ""));
    id_map["ret"] = Pair(0, 1);
    pages[0].stats.push_back(stat);

    string key_list[KEY_N] = {"", "text", "item", "page", "show", "var", "get", "func", "code", "if", "else", "end", "while", "endloop"};
    for (int i = 0; i<KEY_N; i++) Key_map[key_list[i]] = i;

    char op_list[OP_N] = {'(', ')', '{', '}', '&', '|', '=', '!', ',', '-'};
    for (int i = 0; i < OP_N; i++){
        is_operator[op_list[i]] = 1;
    }
}

void annotation_process(){
    pr++;
    if (pr >= str_length) return;
    if (str[pr] == '#'){ //多行注释
        do{
            if (str[pr] == '\\') escape = 1;
            else escape = 0;
            pr++;
            if (str[pr] == '\n'){
                line++; p_line = pr;
            }
            if (pr == str_length) return;
        }while (str[pr] != '#' || escape);
        pr++;
    }else{ //单行注释
        while (str[pr] != '\n'){
            pr++;
            if (pr == str_length) return;
        }
    }
}

bool space_process(){
    do{
        pr++;
        if (pr >= str_length) return 0;
        if (str[pr] == '#') annotation_process();
        if (str[pr] == '\n'){
            line++; p_line = pr;
        }
    }while (str[pr] == ' ' || str[pr] == '\t' || str[pr] == '\n');
    return true;
}

char find_next_char(){
    if (!space_process()) return 0;
    return str[pr];
}

bool is_id_char(){ //id只能由数字、字符、下划线组成
    return isdigit(str[pr]) || isupper(str[pr]) || islower(str[pr]) || str[pr] == '_';
}

bool get_id(){
    str_temp = "";
    pl = pr;
    while (is_id_char()){
        pr++;
    }
    if (str[pr] != ' ' && str[pr] != '\n' && str[pr] != '\t') {
        return false;
    }
    if (str[pr] == '\n'){
        line++; p_line = pr;
    }
    //返回id
    str_temp = str.substr(pl, pr - pl);
    return true;
}

bool get_str(){
    str_temp = "";
    while (true){
        pr++;
        if (pr == str_length) return false; //文本右括号缺失
        if (str[pr] == ']' && !escape) break;
        if (!escape){
            if (str[pr] == '\n') {
                line++; p_line = pr;
            }
            if (str[pr] == '\\') escape = 1;
            else str_temp.append(str, pr, 1);
        }else{
            if (str[pr] == 'n'){
                str_temp.append("\n");
            }else if (str[pr] == 't'){
                str_temp.append("\t");
            }else{
                str_temp.append(str, pr, 1);
                if (str[pr] == '\n'){
                    line++; p_line = pr;
                }
            }
            escape = 0;
        }
    }
    //if (debug_mode) cout << text << endl;
    return true;
}

Sign next_sign;
void find_next_sign(){
    char next_char = find_next_char();
    if (!next_char){
        next_sign = Sign(); return;
    }
    if (next_char == '['){
        //文本
        if (!get_str()) next_sign = Sign(UNKNOWN, "");
        next_sign = Sign(STR, str_temp);
    }else if (is_operator[next_char]){
        next_sign = Sign(OP, &next_char);
    }else{
        if (!get_id()) next_sign = Sign(UNKNOWN, "");
        else if (Key_map[str_temp] != 0) next_sign = Sign(KEY, str_temp);
        else next_sign = Sign(ID, str_temp);
    }
}

void error_process(int type, Sign *sign){
    cerr << "error at line " << line << " char " << pr - p_line - 1 << ":\n";
    string error_description;
    switch (type){
        case 1: error_description = "关键字输入错误"; break;
        case 2: error_description = "动态库打开失败"; break;
            break;
        case 3: error_description = "语句格式错误，该处需要";
            if (sign!=NULL){
                if (sign->type == ID) error_description = error_description + "ID";
                else if (sign->type == STR) error_description = error_description + "文本";
                else if (sign->type == OP) error_description = error_description + "符号" + (sign->val)[0];
            }
            break;
        case 4: error_description = "对象id已被占用"; break;
        case 5: error_description = "逻辑表达式格式错误"; break;
        case 6: error_description = "变量未初始化"; break;
        case 7: error_description = "if-else-end语句未匹配"; break;
        case 8: error_description = "while-endloop语句未匹配"; break;
        default: error_description = "未知错误";
    }
    cerr << error_description << endl;
}

int script_process(string filename){
    ifstream input_file;
    input_file.open(filename);
    if (!input_file.is_open()){
        cerr << "打开脚本文件失败" << endl;
        return 0;
    }else{
        //初始化
        interpreter_init();

        stringstream str_buffer;
        str_buffer << input_file.rdbuf();
        input_file.close();
        str = str_buffer.str();
        str_buffer.clear();
        if (debug_mode) cout << str << endl;
        str_length = str.size();

        int state = 0;
        find_next_sign();
        Statement statement;
        while (true){
            switch (state) {
                case 0:
                    //初始状态
                    if (next_sign.type == KEY) {
                        statement.type = Key_map[next_sign.val];
                        switch (statement.type) {
                            case TEXT: state = 1; break;
                            case ITEM: state = 2;break;
                            case PAGE: case CODE: state = 3; break;
                            case SHOW: case GET: state = 4; break;
                            case VAR: state = 5; break;
                            case FUNC: state = 6; break;
                            case IF: case WHILE: state = 7; break;
                            case ELSE: state = 8; break;
                            case END: state = 13; break;
                            case ENDLOOP: state = 14; break;
                            default:
                                error_process(1, NULL);
                                return 0;
                        }
                    } else if (next_sign.type == OP) {
                        if (next_sign.val[0] == '-') state = 9; //预处理
                        else if (next_sign.val[0] == '}' && now_page.id != "") { //页面出栈
                            if (!if_stack[now_page_n].empty() || !else_stack[now_page_n].empty()){
                                error_process(7, NULL);
                            }
                            page_stack.pop();
                            find_next_sign();
                        } else {
                            error_process(1, NULL);
                            return 0;
                        }
                    } else if (next_sign.type == NONE) {
                        return 1;
                    } else {
                        error_process(1, NULL);
                        return 0;
                    }
                    break;
                case 1: //关键字text
                    find_next_sign();
                    if (next_sign.type == ID) {
                        statement.id = next_sign.val;
                        id_map[statement.id] = Pair(page_stack.top(), now_page.stats.size());
                        find_next_sign();
                        if (next_op != '=') {
                            Sign expected_sign = Sign(OP, "=");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        find_next_sign();
                    }
                    if (next_sign.type != STR) {
                        Sign expected_sign = Sign(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    while (next_sign.type == STR) {
                        statement.signs.push_back(next_sign);
                        find_next_sign();
                    }
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 2: //关键字item
                    find_next_sign();
                    if (next_sign.type == ID) {
                        statement.id = next_sign.val;
                        id_map[statement.id] = Pair(page_stack.top(), now_page.stats.size());
                        find_next_sign();
                        if (next_op != '=') {
                            Sign expected_sign = Sign(OP, "=");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        find_next_sign();
                    }
                    if (next_op != '{') {
                        Sign expected_sign = Sign(OP, "{");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    //至少读入两个id/str
                    find_next_sign();
                    if (next_sign.type != ID && next_sign.type != STR) {
                        Sign expected_sign = Sign(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.signs.push_back(next_sign);
                    find_next_sign();
                    if (next_sign.type != ID && next_sign.type != STR) {
                        Sign expected_sign = Sign(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.signs.push_back(next_sign);
                    find_next_sign();
                    while (next_sign.type == ID) {
                        statement.signs.push_back(next_sign);
                        find_next_sign();
                    }
                    if (next_op != '}') {
                        Sign expected_sign = Sign(OP, "}");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    find_next_sign();
                    state = 0;
                    break;
                case 3: //关键字page
                    find_next_sign();
                    if (next_sign.type != ID) {
                        Sign expected_sign = Sign(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    if (ID_exists(next_sign.val)) {
                        error_process(4, NULL);
                        return 0;
                    }
                    statement.signs.push_back(Sign(STR, to_string(page_n)));
                    statement.id = next_sign.val;
                    id_map[statement.id] = Pair(0, pages[0].stats.size());
                    pages[0].stats.push_back(statement);
                    page_stack.push(page_n++);
                    pages.push_back(Page(statement.id));
                    statement = Statement();
                    find_next_sign();
                    if (next_op != '=') {
                        Sign expected_sign = Sign(OP, "=");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_sign();
                    if (next_op != '{') {
                        Sign expected_sign = Sign(OP, "{");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_sign();
                    state = 0;
                    break;
                case 4: //关键字show, get
                    find_next_sign();
                    if (next_sign.type != ID) {
                        Sign expected_sign = Sign(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.id = next_sign.val;
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    find_next_sign();
                    state = 0;
                    break;
                case 5: //关键字var
                    find_next_sign();
                    if (next_sign.type != ID) {
                        Sign expected_sign = Sign(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    if (!ID_exists(next_sign.val)) { //变量初始声明
                        string val_id = next_sign.val;
                        find_next_sign();
                        if (next_sign.type != STR) {
                            error_process(6, NULL);
                            return 0;
                        }
                        id_map[val_id] = Pair(0, pages[0].stats.size());
                        statement.id = val_id;
                        statement.signs.push_back(Sign(STR, next_sign.val));
                        pages[0].stats.push_back(statement);
                        find_next_sign();
                    } else {
                        if (ID_to_stat(next_sign.val).type != VAR) {
                            error_process(4, NULL);
                            return 0;
                        }
                        statement.id = next_sign.val;
                        find_next_sign();
                        if (next_op != '=') {
                            Sign expected_sign = Sign(OP, "=");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        find_next_sign();
                        if (next_sign.type != ID && next_sign.type != STR) {
                            Sign expected_sign = Sign(STR, "");
                            error_process(3, &expected_sign);
                            return 0;
                        }
                        while (next_sign.type == ID || next_sign.type == STR) {
                            statement.signs.push_back(next_sign);
                            find_next_sign();
                        }
                        now_page.stats.push_back(statement);
                    }
                    statement = Statement();
                    state = 0;
                    break;
                case 6: //关键字func
                    find_next_sign();
                    if (next_sign.type != ID) {
                        Sign expected_sign = Sign(ID, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    statement.id = next_sign.val;
                    find_next_sign();
                    if (next_op != '{') {
                        Sign expected_sign = Sign(OP, "{");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_sign();
                    if (next_sign.type != STR && next_sign.type != ID) {
                        Sign expected_sign = Sign(STR, "");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    while (next_sign.type == STR || next_sign.type == ID) {
                        statement.signs.push_back(next_sign);
                        find_next_sign();
                    }
                    if (next_op != '}') {
                        Sign expected_sign = Sign(OP, "}");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    find_next_sign();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 7: { //关键字if/while
                    //if ( as = [] | pf ! t  & ( x = i & t ! f ) )
                    while (!op_stack.empty()) op_stack.pop();
                    while (!str_stack.empty()) str_stack.pop();
                    find_next_sign();
                    if (next_op != '(') {
                        Sign expected_sign = Sign(OP, "(");
                        error_process(3, &expected_sign);
                        return 0;
                    }
                    if (statement.type == IF) if_stack[now_page_n].push(now_page.stats.size());
                    else while_stack[now_page_n].push(now_page.stats.size());
                    op_stack.push(next_sign);
                case 10:
                    find_next_sign();
                    if (next_op == '(') {
                        op_stack.push(next_sign);
                        state = 10;
                    } else if (next_sign.type == STR || next_sign.type == ID) {
                        str_stack.push(next_sign);
                        find_next_sign();
                        if (next_op == '=' || next_op == '!') {
                            op_stack.push(next_sign);
                        } else {
                            error_process(5, NULL);
                            return 0;
                        }
                        find_next_sign();
                        if (next_sign.type == STR || next_sign.type == ID) {
                            str_stack.push(next_sign);
                        } else {
                            error_process(5, NULL);
                            return 0;
                        }
                        state = 11;
                    } else {
                        error_process(5, NULL);
                        return 0;
                    }
                    break;
                }
                case 8:
                    if (if_stack[now_page_n].empty()) {
                        error_process(7, NULL);
                        return 0;
                    }
                    now_page.stats[if_stack[now_page_n].top()].id = to_string(now_page.stats.size());
                    if_stack[now_page_n].pop();
                    else_stack[now_page_n].push(now_page.stats.size());
                    find_next_sign();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 9:
                    find_next_sign();
                    if (next_sign.val == "SET_DLL_DIRECTORY"){
                        find_next_char();
                        pl = pr;
                        while (str[pr] != ' ' && str[pr] != '\n' && str[pr] != '\t') pr++;
                        if (str[pr] == '\n'){
                            line++; p_line = pr;
                        }
                        string dll_directory = str.substr(pl, pr - pl);
#ifdef _WIN32
                        hLibrary = LoadLibrary(str.substr(pl, pr - pl).c_str());
#else
                        handle = dlopen(dll_directory.c_str(), RTLD_LAZY);
                        if (handle == NULL){
                            error_process(2, 0); return 0;
                        }
#endif
                        //if (handle!=NULL) cout << str.substr(pl, pr - pl) << endl;
                    }
                    find_next_sign();
                    state = 0;
                    break;
                case 11:
                    find_next_sign();
                    if (next_op == '&' || next_op == '|'){
                        statement.signs.push_back(str_stack.top());
                        str_stack.pop();
                        statement.signs.push_back(str_stack.top());
                        str_stack.pop();
                        while (top_op != '(') {
                            statement.signs.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.push(next_sign);
                        state = 10;
                    }else if (next_op == ')'){
                        statement.signs.push_back(str_stack.top());
                        str_stack.pop();
                        statement.signs.push_back(str_stack.top());
                        str_stack.pop();
                        while (top_op != '(') {
                            statement.signs.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.pop();
                        if (op_stack.empty()){
                            find_next_sign();
                            now_page.stats.push_back(statement);
                            statement = Statement();
                            state = 0;
                        }else{
                            state = 12;
                        }
                    }else{
                        error_process(5, NULL);
                        return 0;
                    }
                    break;
                case 12:
                    find_next_sign();
                    if (next_op == '&' || next_op == '|'){
                        while (top_op != '(') {
                            statement.signs.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.push(next_sign);
                        state = 10;
                    }else if (next_op == ')'){
                        while (top_op != '(') {
                            statement.signs.push_back(op_stack.top());
                            op_stack.pop();
                        }
                        op_stack.pop();
                        if (op_stack.empty()){
                            find_next_sign();
                            now_page.stats.push_back(statement);
                            statement = Statement();
                            state = 0;
                        }
                    }else{
                        error_process(5, NULL);
                        return 0;
                    }
                    break;
                case 13:
                    if (!else_stack[now_page_n].empty()) {
                        now_page.stats[else_stack[now_page_n].top()].id = to_string(now_page.stats.size());
                        else_stack[now_page_n].pop();
                    }else if (!if_stack[now_page_n].empty()){
                        now_page.stats[if_stack[now_page_n].top()].id = to_string(now_page.stats.size());
                        if_stack[now_page_n].pop();
                    }else{
                        error_process(7, NULL);
                        return 0;
                    }
                    find_next_sign();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                case 14:
                    if (!while_stack[now_page_n].empty()){
                        now_page.stats[while_stack[now_page_n].top()].id = to_string(now_page.stats.size());
                        statement.id = to_string(while_stack[now_page_n].top());
                        while_stack[now_page_n].pop();
                    }else{
                        error_process(8, NULL);
                        return 0;
                    }
                    find_next_sign();
                    now_page.stats.push_back(statement);
                    statement = Statement();
                    state = 0;
                    break;
                default: return 0;
            }
        }
    }
}

