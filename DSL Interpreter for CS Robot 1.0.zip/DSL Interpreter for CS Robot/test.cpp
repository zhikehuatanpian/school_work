#include "head.h"

string key_list[KEY_N] = {"", "TEXT", "ITEM", "PAGE", "SHOW", "VAR", "GET", "FUNC", "CODE", "IF", "ELSE", "END", "WHILE", "ENDLOOP"};
string type_list[UNKNOWN] = {"", "STR", "ID", "OP", "KEY"};

void print_syntax_tree(){
    for (int i = 0; i < pages.size(); i ++){
        cout << "Page " << pages[i].id << ":\n" ;
        for (int j = 0; j < pages[i].stats.size(); j++) {
            cout << "\ttype: " << key_list[pages[i].stats[j].type] << "  id: " << pages[i].stats[j].id << endl;
            for (int k = 0; k < pages[i].stats[j].signs.size(); k++) {
                if (pages[i].stats[j].signs[k].type == OP) cout << "\t\tsign" << k << ": " << type_list[pages[i].stats[j].signs[k].type] << "  " << pages[i].stats[j].signs[k].val[0] << endl;
                else cout << "\t\tsign" << k << ": " << type_list[pages[i].stats[j].signs[k].type] << " " << pages[i].stats[j].signs[k].val << endl;
            }
        }
    }
}

