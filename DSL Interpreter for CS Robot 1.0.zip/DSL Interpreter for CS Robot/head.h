#ifndef HEAD_H
#define HEAD_H
#endif

#include <iostream>
#include <fstream>
#include <sstream>
#include <variant>

#include <vector>
#include <map>
#include <unordered_map>
#include <set>

#include <pthread.h>
#include <sys/event.h>
#include <sys/time.h>

//python头文件目录
#ifdef _WIN32
    #include <windows.h>
#else
    #include <dlfcn.h>
#endif

using namespace std;

#define MAX_PAGE_N 100
#define MAX_STAT_N 200

extern int debug_mode;
/*#ifdef NDEBUG
    debug_mode = 0;
#endif*/
enum KEY_TYPE {
    NONE, TEXT, ITEM, PAGE, SHOW, VAR, GET, FUNC, CODE, IF, ELSE, END, WHILE, ENDLOOP, KEY_N
};
enum COMMAND_TYPE {
    QUIT = 1, GO, LOAD, REFRESH, RETURN, COMMAND_N
};
enum SIGN_TYPE {
    STR = 1, ID, OP, KEY, UNKNOWN
};

extern unordered_map<string, int> Key_map;
extern unordered_map<string, int> Command_map;
extern unordered_map<string, string> Val_map; //存放变量，每个用户单独拥有

typedef struct Sign{
    int type = NONE;
    string val;
    Sign(){}
    Sign(int _type, string _val){
        type = _type, val = _val;
    }
};

typedef struct Statement{
    int type = NONE;
    string id = "";
    vector<Sign> signs;
    Statement(){}
    Statement(int _type, string _id){
        type = _type;
        id = _id;
    }
}*pStatement;

typedef pair<int,int> Pair;
extern unordered_map<string, Pair> id_map; //将id映射到语法树的某个位置，该位置存放id对应成员的信息

typedef struct Page{
    string id;
    vector<Statement> stats;
    Page(){}
    Page(string _id){
        id = _id;
    }
};
extern vector<Page> pages;
#ifdef _WIN32
    extern HMODULE hLibrary;
#else
    extern void* handle;
#endif

#define ID_to_stat(x) (pages[id_map[x].first].stats[id_map[x].second])
#define ID_exists(x) (id_map[x].first || id_map[x].second)
#define ID_type(x) (ID_exists(x)?ID_to_stat(x).type:0)

int script_process(string filename);

bool get_output(string command);
void init_command_map();
void print_page(int idx);

void print_syntax_tree();


